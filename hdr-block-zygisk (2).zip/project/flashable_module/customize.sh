#!/system/bin/sh
# Runs once at install time (Magisk/KernelSU Manager calls this automatically).

ui_print "- Installing HDR Block Zygisk module"

# targets.txt controls which apps get hooked. One package name per line,
# '#' for comments. Empty file = hook everything (global mode).
# Only create it if missing, so re-flashing an update doesn't wipe your list.
if [ ! -f "$MODPATH/targets.txt" ]; then
  touch "$MODPATH/targets.txt"
fi
set_perm "$MODPATH/targets.txt" 0 0 0644

# classes.dex is read by the module's companion process (running as root)
# and streamed into each target app process. World-readable is fine since
# only our own root-privileged companion ever opens it, but keep it tight.
set_perm "$MODPATH/classes.dex" 0 0 0644

ui_print "- Done. Reboot to activate."
